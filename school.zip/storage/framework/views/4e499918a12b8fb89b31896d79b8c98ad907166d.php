<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-chosen.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrum'); ?>
<div class="row">
	<div class="col-md-8">
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="<?php echo e(route('institution.dashboard')); ?>">Inicio</a></li>
		  <li class="breadcrumb-item"><a href="<?php echo e(route('headquarter.index')); ?>">Sedes</a></li>
		  <li class="breadcrumb-item active">Crear</li>
		</ol>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="row">
		<div class="col-md-8">
			<h4>Crear sede</h4>
			<hr>
			<div class="card">
				<div class="card-body">
					<?php echo Form::open(['route' => 'headquarter.store', 'method' => 'post', 'files'=>true]); ?>

						
				  			<div id="identification" class="section_inscription">
					  			<div class="row">
					  				<div class="col-md-6">
					  					<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
					  						<?php echo Form::label('name', 'Nombre de la sede'); ?>

					  						<?php echo Form::text('name', null, ['class'=>'form-control']); ?>

					  					</div>
					  				</div>
					  				<div class="col-md-6">
					  					<div class="form-group">
					  						<?php echo Form::label('nit', 'NIT'); ?>

					  						<?php echo Form::text('nit', null, ['class'=>'form-control']); ?>

					  					</div>
					  				</div>
					  			</div>
					  		</div>
					  		
				  			<div id="identification" class="section_inscription">
				  				<div class="section_inscription__tittle">
				  					<h5>Dirección Residencia</h5>
				  					<hr>
				  				</div>
				  				<div class="row">
				  					<div class="col-md-3">
				  						<div class="form-group <?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
				  							<?php echo Form::label('address', 'Dirección'); ?>

				  							<?php echo Form::text('address', old('address'), ['class' => 'form-control', 'id'=>'adress']); ?>

				  						</div>
				  					</div>
				  					<div class="col-md-3">
				  						<div class="form-group <?php echo e($errors->has('neighborhood') ? ' has-error' : ''); ?>">
				  							<?php echo Form::label('neighborhood', 'Barrio'); ?>

				  							<?php echo Form::text('neighborhood', old('neighborhood'), ['class' => 'form-control', 'id'=>'neighborhood']); ?>

				  						</div>
				  					</div>
				  					<div class="col-md-3">
				  						<div class="form-group <?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
				  							<?php echo Form::label('phone', 'Telefono'); ?>

				  							<?php echo Form::text('phone', old('phone'), ['class' => 'form-control', 'id'=>'phone']); ?>

				  						</div>
				  					</div>
				  					<div class="col-md-3">
				  						<div class="form-group <?php echo e($errors->has('mobil') ? ' has-error' : ''); ?>">
				  							<?php echo Form::label('mobil', 'Celular'); ?>

				  							<?php echo Form::text('mobil', old('mobil'), ['class' => 'form-control', 'id'=>'mobil']); ?>

				  						</div>
				  					</div>
				  				</div>
				  				<div class="row">
				  					<div class="col-md-4">
				  						<div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
				  							<?php echo Form::label('email', 'Email'); ?>

				  							<?php echo Form::text('email', old('email'), ['class' => 'form-control', 'id'=>'email']); ?>

				  						</div>
				  					</div>
				  					<div class="col-md-4">
				  						<div class="form-group <?php echo e($errors->has('id_city_address') ? ' has-error' : ''); ?>">
				  							<?php echo Form::label('id_city_address', 'Ciudad'); ?>

				  							<?php echo Form::select('id_city_address', $cities, old('id_city_address'), ['class'=>'chosen-select form-control chosen-select', 'placeholder'=>'seleccione una ciudad']); ?>

				  						</div>
				  					</div>
				  				</div>
				  			</div>
				  			
				  			<div class="picture">
				  				<div class="section_inscription__tittle">
				  					<h5>Foto</h5>
				  					<hr>
				  				</div>
				  				<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<div class="input-group">
											   <span class="input-group-btn">
											     <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-secondary">
											       <i class="fa fa-picture-o"></i> Choose
											     </a>
											   </span>
											   <input id="thumbnail" class="form-control" type="text" name="avatar">
											 </div>
											 <img id="holder" style="margin-top:15px;max-height:100px;">
										</div>
									</div>
								</div>
				  			</div>
				  			
			  				<div class="row">
			  					<div class="col-md-12">
			  						<div class="form-group text-center">
			  							<?php echo Form::hidden('institution_id', Auth()->guard('web_institution')->user()->id); ?>

			  							<button class="btn btn-block btn-primary">Crear</button>
			  						</div>
			  					</div>
			  				</div>
					<?php echo Form::close(); ?>

				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script src="<?php echo e(asset('js/chosen.jquery.js')); ?>"></script>
	<script src="/vendor/laravel-filemanager/js/lfm.js"></script>

	<script>
		$(function() {
			
			$('#lfm').filemanager('image');	

	        $('.chosen-select').chosen({width: "100%"});
	        $('.chosen-select-deselect').chosen({ allow_single_deselect: true });
	        $('.datepicker').datepicker({
			    format: 'yyyy/mm/dd',
			    startDate: '-3d'
			});
    	});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('institution.dashboard.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>