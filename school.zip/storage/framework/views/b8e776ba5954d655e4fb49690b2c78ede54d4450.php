<div class="modal fade" id="addItemModal" tabindex="-1" role="dialog" aria-labelledby="addItemModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <?php echo Form::open(['route' => 'menu.addItem', 'method' => 'post']); ?>

        <div class="modal-header">
          <h5 class="modal-title" id="addItemModalLabel">Agregar Item</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="container-fuild">
            <div class="row">
              <div class="col-md-12">
                <?php echo Form::label('title', 'Titutlo', []); ?>

                <?php echo Form::text('title', null, ['class'=>'form-control']); ?>

              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <?php echo Form::label('url', 'URL', []); ?>

                <?php echo Form::text('url', null, ['class'=>'form-control']); ?>

              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <?php echo Form::label('parent_id', 'Superior', []); ?>

                <?php echo Form::select('parent_id', $items_add, null, ['class'=>'form-control', 'placeholder'=>'Item superior']); ?>

              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <?php echo Form::label('target', 'Abrir en ', []); ?>

                <?php echo Form::select('target', ['_blank' => 'nueva ventana','_self' => 'en la misma pagina'],'_self', ['class'=>'form-control']); ?>

              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <?php echo Form::hidden('menu_id', $menu->id, []); ?>

          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
          <?php echo Form::submit('Agregar', ['class'=>'btn btn-primary']); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>