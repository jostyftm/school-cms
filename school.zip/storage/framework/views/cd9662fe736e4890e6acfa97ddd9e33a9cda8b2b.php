<?php $__env->startSection('posts'); ?>
	<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<article class="blog-post">
		<header>
			<h2 class="blog-post-title">
				<a href="<?php echo e(route('post.view', $post->slug)); ?>"><?php echo e($post->title); ?></a>
			</h2>
			<p class="blog-post-meta">
				<time><?php echo e($post->created_at); ?></time>
			</p>
		</header>
		<img src="<?php echo e($post->image); ?>" alt="" class="blog-post-image card-img-top">
		<a href="<?php echo e(route('post.view', $post->slug)); ?>">Leer mas →</a>
	</article>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php echo e($posts->render("pagination::bootstrap-4")); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('post.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>