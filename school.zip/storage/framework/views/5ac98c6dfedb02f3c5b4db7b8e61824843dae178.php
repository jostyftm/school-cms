<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="">

    <title>Blog Template for Bootstrap</title>

    <!-- Bootstrap core CSS -->
    <link href="/css/bootstrap.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">
    <link href="/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/blog.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('css'); ?>

  </head>

  <body>
	<header>
      <div class="blog-masthead">
        <div class="container">
          <?php echo $__env->make('menu.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
      </div>

      <div class="blog-header">
        <div class="container">
          <h1 class="blog-title">The Bootstrap Blog</h1>
          <p class="lead blog-description">An example blog template built with Bootstrap.</p>
        </div>
      </div>
    </header>

    <main role="main" class="container">

      <div class="row">
      	<div class="col-sm-8 blog-main">
			<?php echo $__env->yieldContent('posts'); ?>
      	</div>
      	<aside class="col-sm-3 ml-sm-auto blog-sidebar">
          	
        </aside>
     </div>
  	</main>
    
	 <!-- Scripts -->
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>
  </body>
</html>