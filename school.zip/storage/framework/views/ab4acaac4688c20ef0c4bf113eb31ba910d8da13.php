<?php $__env->startSection('breadcrum'); ?>
<div class="row">
	<div class="col-md-12">
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="<?php echo e(route('institution.dashboard')); ?>">Inicio</a></li>
		  <li class="breadcrumb-item active">Role</li>
		</ol>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="row">
		<div class="col-md-12">
			<div class="clearfix">
				<h4 class="float-left">Roles</h4>
				<a href="<?php echo e(route('role.create')); ?>" class="float-right btn btn-sm btn-primary">Nuevo rol</a>
			</div>
			<hr>	
			<div class="card">
				<div class="card-body">
					<table class="table">
						<thead>
							<tr>
								<th>Rol</th>
								<th>Acción</th>
						</thead>
						</tr>
							<tbody>
							<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo $role->name; ?></td>
								<td>
									<a href="<?php echo e(route('role.edit', $role)); ?>" class="btn btn-outline-primary btn-sm" title="Editar Rol">
										<i class="fa fa-edit"></i>
									</a>
									<a href="<?php echo e(route('role.destroy', $role)); ?>" class="btn btn-outline-danger btn-sm" title="Eliminar Rol">
										<i class="fa fa-trash"></i>
									</a>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('institution.dashboard.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>