<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/toastr.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrum'); ?>
<div class="row">
	<div class="col-md-12">
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="<?php echo e(route('institution.dashboard')); ?>">Inicio</a></li>
		  <li class="breadcrumb-item"><a href="<?php echo e(route('menu.index')); ?>">Menu</a></li>
		  <li class="breadcrumb-item active">Construir</li>
		</ol>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="row">
		<div class="col-md-12">
			<div class="clearfix">
				<h4 class="float-left">Menu - <?php echo e($menu->name); ?></h4>
				<button type="button" data-toggle="modal" data-target="#addItemModal" class="float-right btn btn-sm btn-primary">Agregar item</button>
			</div>
			<hr>
			<div class="card">
				<div class="card-body">
					<div class="dd" id="nestable3">
						<?php echo $__env->make('institution.partials.menu.menu_list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
			</div>
		</div>	
	</div>
	<?php echo $__env->make('institution.partials.menu.addItem', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('institution.partials.menu.editItem', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script src="<?php echo e(asset('js/jquery.nestable.js')); ?>"></script>
	<script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
	<script>
		$(document).ready(function(){
			$('#nestable3').nestable();

			$('.editItem').click(function(e){
				e.preventDefault();

				let _this = $(this),
					_item_id = _this.parent().parent().data('id');

				$.get('/ajax/'+_item_id+'/findMenuItem', function(data){
					fillEditForm(data);
				}, 'json');
			});

			$('#formEditItem').submit(function(e){
				
				let _this = $(this)
				    _id = _this.find('#id').val();

				e.preventDefault();

				$.ajax({
					url: '/institution/'+_id+'/updateItem',
					method: 'PUT',
					data: _this.serialize(),
					success: function(data){
						window.location.reload();
					},
					error: function(xhr, status){
						console.log(xhr);
						console.log(status);
					}
				});
			});

			$('.dd').change(function(){
				$.post('/institution/menu/<?php echo e($menu->id); ?>/orderMenu', {
					order: JSON.stringify($('.dd').nestable('serialize')),
					_token: '<?php echo e(csrf_token()); ?>'
				}, function(data){
					toastr.success('Se ordeno el menu');
				});
			});

			let fillEditForm = function(data){
				let _modal = $('#editItemModal'),
				 	_mTitle = _modal.find('#title'),
				 	_mUrl	= _modal.find('#url'),
				 	_mParent = _modal.find('#parent_id'),
				 	_mTarget = _modal.find('#target');
				 	_mId 	= _modal.find('#id');

				_mTitle.val(data.title);
				_mUrl.val(data.url);
				_mParent.val(data.parent_id);
				_mTarget.val(data.target);
				_mId.val(data.id);

				_modal.modal({
					keyboard: false,
					backdrop: 'static',
				});
			}
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('institution.dashboard.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>