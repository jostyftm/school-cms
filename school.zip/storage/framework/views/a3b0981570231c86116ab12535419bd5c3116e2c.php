<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'MultiAuth')); ?></title>

    <!-- Styles -->
    <link href="/css/bootstrap.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">
    <link href="/css/font-awesome.min.css" rel="stylesheet">
    <?php echo $__env->yieldContent('css'); ?>

    
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Roboto:400,700" rel="stylesheet">

    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
</head>
<body>
	   
    
    <?php echo $__env->make('institution.dashboard.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container-fluid">
        
        <div class="row">
            <div class="col-sm-3 col-md-2 sidebar p-0" id="sidebar">
                <?php echo $__env->make('institution.dashboard.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>    
             <main class="col-md-10 col-sm-9 main">
                <?php echo $__env->yieldContent('breadcrum'); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>

    </div>

    
    
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>

</body>