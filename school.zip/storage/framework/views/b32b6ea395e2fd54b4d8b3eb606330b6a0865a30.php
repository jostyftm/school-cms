<?php $__env->startSection('breadcrum'); ?>
<div class="row">
	<div class="col-md-12">
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="<?php echo e(route('institution.dashboard')); ?>">Inicio</a></li>
		  <li class="breadcrumb-item active">Menu</li>
		</ol>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-8">
			<h4>Crear menu</h4>
			<hr>
			<div class="card">
				<div class="card-body">
					<?php echo Form::open(['route' => 'menu.store', 'method' => 'post']); ?>

						
				  			<div id="identification" class="section_inscription">
					  			<div class="row">
					  				<div class="col-md-12">
					  					<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
					  						<?php echo Form::label('name', 'Nombre del menu'); ?>

					  						<?php echo Form::text('name', null, ['class'=>'form-control']); ?>

					  					</div>
					  				</div>
					  			</div>
					  		</div>
				  			
			  				<div class="row">
			  					<div class="col-md-12">
			  						<div class="form-group text-center">
			  							<button class="btn btn-block btn-primary">Crear</button>
			  						</div>
			  					</div>
			  				</div>
					<?php echo Form::close(); ?>

				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('institution.dashboard.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>