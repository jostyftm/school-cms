<?php $__env->startSection('breadcrum'); ?>
<div class="row">
	<div class="col-md-12">
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="<?php echo e(route('institution.dashboard')); ?>">Inicio</a></li>
		  <li class="breadcrumb-item active">Página</li>
		</ol>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<div class="clearfix">
				<h4 class="float-left">Página</h4>
				<a href="<?php echo e(route('page.create')); ?>" class="float-right btn btn-sm btn-primary">Nueva Página</a>
			</div>
			<hr>
			<div class="card">
				<div class="card-body">
					<table class="table">
						<thead>
							<tr>
								<th>Titulo</th>
								<th>Estado</th>
								<th>Url</th>
								<th>Fecha de creación</th>
								<th>Accion</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo $page->title; ?></td>
								<td><?php echo $page->state; ?></td>
								<td><?php echo e(env('APP_URL')); ?>/<?php echo $page->slug; ?></td>
								<td><?php echo $page->created_at; ?></td>
								<td>
									<a href="<?php echo e(route('page.show', $page)); ?>" class="btn btn-outline-secondary btn-sm" title="Editar Página" target="_blank">
										<i class="fa fa-eye"></i>
									</a>
									<a href="<?php echo e(route('page.edit', $page)); ?>" class="btn btn-outline-primary btn-sm" title="Editar Página">
										<i class="fa fa-edit"></i>
									</a>
									<a href="<?php echo e(route('page.destroy', $page)); ?>" class="btn btn-outline-danger btn-sm" title="Eliminar Página" onclick="return confirm('Desea eliminar esta página')">
										<i class="fa fa-trash"></i>
									</a>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
					<?php echo e($pages->render("pagination::bootstrap-4")); ?>

				</div>
			</div>
		</div>	
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('institution.dashboard.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>