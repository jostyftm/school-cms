<?php $__env->startSection('css'); ?>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrum'); ?>
<div class="row">
	<div class="col-md-12">
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="<?php echo e(route('institution.dashboard')); ?>">Inicio</a></li>
		  <li class="breadcrumb-item"><a href="<?php echo e(route('post.index')); ?>">Entradas</a></li>
		  <li class="breadcrumb-item active">Crear</li>
		</ol>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<div>
				<h4>Editar entrada</h4>
			</div>
			<hr>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<?php echo Form::open(['route' => ['post.update', $post], 'method' => 'put', 'files'=>true]); ?>

					<?php echo e(csrf_field()); ?>

						
			  			<div class="section_inscription">
				  			<div class="row">
				  				<div class="col-md-12">
				  					<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
				  						<?php echo Form::label('title', 'Titulo'); ?>

				  						<?php echo Form::text('title', $post->title, ['class'=>'form-control']); ?>

				  					</div>
				  				</div>
				  			</div>
				  			<div class="row">
				  				<div class="col-md-12">
				  					<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
				  						<?php echo Form::label('body', 'Descripción'); ?>

				  						<?php echo Form::textarea('body', $post->body, ['class'=>'form-control']); ?>

				  					</div>
				  				</div>
				  			</div>
						    <div class="row">
						    	<div class="col-md-6">
						    		<div class="form-group<?php echo e($errors->has('state') ? ' has-error' : ''); ?>">
							  			<?php echo Form::label('state', 'Estado'); ?>

							  			<?php echo Form::select('state', 
							  				[
							  					'active' => 'Activo',
							  					'inactive'=> 'Inactivo'
							  				], $post->state, ['class'=>'form-control']); ?>

							  		</div>
						    	</div>
						    	
						    </div>
						    <div class="row">
							    <div class="col-md-12">
							    	<div class="form-group">
							    		<label for="">Imagen de la entrada</label>
										<div class="input-group">
										   <span class="input-group-btn">
										     <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-secondary">
										       <i class="fa fa-picture-o"></i> Choose
										     </a>
										   </span>
										   <input id="thumbnail" class="form-control" type="text" name="image" value="<?php echo e($post->image); ?>">
										 </div>
										 <img id="holder" style="margin-top:15px;max-height:100px;" src="<?php echo e($post->image); ?>">
									</div>
							 	</div>
							</div>
				  		</div>
			  			
		  				<div class="row">
		  					<div class="col-md-12">
		  						<div class="form-group text-center">
		  							<button class="btn btn-block btn-primary">Actualizar</button>
		  						</div>
		  					</div>
		  				</div>
					<?php echo Form::close(); ?>

				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script src="<?php echo e(asset('plugin/ckeditor/ckeditor.js')); ?>"></script>
	<script src="/vendor/laravel-filemanager/js/lfm.js"></script>
	<script>
		$(document).ready(function() {
		  	
		  	$('#lfm').filemanager('image');	

		  	var options = {
			    filebrowserImageBrowseUrl: '/laravel-filemanager?type=Images',
			    filebrowserImageUploadUrl: '/laravel-filemanager/upload?type=Images&_token=',
			    filebrowserBrowseUrl: '/laravel-filemanager?type=Files',
			    filebrowserUploadUrl: '/laravel-filemanager/upload?type=Files&_token=',
			    language: 'es',
			};

		  	CKEDITOR.replace( 'body', options);

		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('institution.dashboard.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>