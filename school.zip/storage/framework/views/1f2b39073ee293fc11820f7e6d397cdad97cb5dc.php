<?php if(count($item->items) == 0): ?>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url($item->url)); ?>"><?php echo e($item->title); ?> </a>
    </li>
<?php else: ?>
    <li class="nav-item dropdown">
        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e($item->title); ?> 
            <span class="caret"></span>
        </a>
        <ul class="dropdown-menu">
            <?php $__currentLoopData = $item->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($item1->items) == 0): ?>
                    <li><a href="<?php echo e(url($item1->url)); ?>" class="dropdown-item"><?php echo e($item1->title); ?> </a></li>
                <?php else: ?>
                    <?php echo $__env->make('menu.menu-item', [ 'item' => $item1 ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </li>
<?php endif; ?>