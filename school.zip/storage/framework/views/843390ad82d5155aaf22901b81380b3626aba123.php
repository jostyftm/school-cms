<?php $__env->startSection('breadcrum'); ?>
<div class="row">
	<div class="col-md-12">
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="<?php echo e(route('institution.dashboard')); ?>">Inicio</a></li>
		  <li class="breadcrumb-item active">Grupo</li>
		</ol>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="row">
		<div class="col-md-12">
			<div class="clearfix">
				<h4 class="float-left">Grupos</h4>
				<a href="<?php echo e(route('group.create')); ?>" class="float-right btn btn-sm btn-primary">Nuevo grupo</a>
			</div>
			<hr>
			<div class="card">
				<div class="card-body">
					
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('institution.dashboard.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>