@extends('institution.dashboard.index')

@section('breadcrum')
<div class="row">
	<div class="col-md-10">
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="{{route('institution.dashboard')}}">Inicio</a></li>
		  <li class="breadcrumb-item active">Configuración</li>
		</ol>
	</div>
</div>
@endsection

@section('content')
	
	<div class="row">
		<div class="col-md-10">
			<h4>Configuración</h4>
			<hr>	
			<div class="card">
				<div class="card-body">
					
				</div>
			</div>
		</div>
	</div>

@endsection